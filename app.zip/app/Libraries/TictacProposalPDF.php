<?php
/**
 * Clase TCPDF personalizada para los presupuestos de Tictac Comunicación.
 * Este archivo se incluye mediante require_once DENTRO de _generate_tictac_pdf(),
 * DESPUÉS de que tcpdf.php ya haya sido cargado, para que TCPDF esté disponible.
 *
 * Ruta en servidor: /home/gestiontictaccom/public_html/app/Libraries/TictacProposalPDF.php
 */

if (!class_exists('TictacProposalPDF')) {

    class TictacProposalPDF extends TCPDF
    {
        public $brand_r   = 215;
        public $brand_g   = 33;
        public $brand_b   = 115;
        public $logo_path = '';

        public function Header()
        {
            $pageW = $this->getPageWidth();

            // ── Franja superior delgada rosa (solo 2mm) ───────────────────
            $this->SetFillColor($this->brand_r, $this->brand_g, $this->brand_b);
            $this->Rect(0, 0, $pageW, 2, 'F');

            // ── Fondo blanco del header ───────────────────────────────────
            $this->SetFillColor(255, 255, 255);
            $this->Rect(0, 2, $pageW, 26, 'F');

            // ── Bloque rosa izquierda con logo ────────────────────────────
            if ($this->logo_path && file_exists($this->logo_path)) {
                $this->SetFillColor($this->brand_r, $this->brand_g, $this->brand_b);
                $this->Rect(0, 2, 48, 26, 'F');
                $logoW = 38;
                $logoX = (48 - $logoW) / 2;
                $logoH = 14;
                $logoY = 2 + (26 - $logoH) / 2;
                $this->Image($this->logo_path, $logoX, $logoY, $logoW, 0, '', '', '', false, 300, '', false, false, 0, false, false, false);
            }

            // ── "PRESUPUESTO" — centrado verticalmente ────────────────────
            $this->SetTextColor($this->brand_r, $this->brand_g, $this->brand_b);
            $this->SetFont('Helvetica', 'B', 16);
            $this->SetXY(52, 2 + (26 - 8) / 2);
            $this->Cell(60, 8, 'PRESUPUESTO', 0, 0, 'L');

            // ── Info empresa — derecha, centrada verticalmente ────────────
            $lineH   = 3.8;
            $nLineas = 3;
            $bloqueH = $nLineas * $lineH;
            $inicioY = 2 + (26 - $bloqueH) / 2;

            $this->SetFont('Helvetica', 'B', 7);
            $this->SetTextColor(60, 60, 60);
            $this->SetXY($pageW - 72, $inicioY);
            $this->Cell(70, $lineH, 'Tictac Comunicación Digital SL', 0, 1, 'R');

            $this->SetFont('Helvetica', '', 6.5);
            $this->SetTextColor(130, 130, 130);
            $this->SetX($pageW - 72);
            $this->Cell(70, $lineH, 'hola@tictac-comunicacion.es  ·  633 33 53 90', 0, 1, 'R');
            $this->SetX($pageW - 72);
            $this->Cell(70, $lineH, 'www.tictac-comunicacion.es', 0, 1, 'R');

            // ── Línea inferior rosa ───────────────────────────────────────
            $this->SetDrawColor($this->brand_r, $this->brand_g, $this->brand_b);
            $this->SetLineWidth(0.6);
            $this->Line(0, 28, $pageW, 28);

            $this->SetTextColor(51, 51, 51);
            $this->SetMargins(15, 34, 15);
            $this->SetY(34);
        }

        public function Footer()
        {
            $pageW = $this->getPageWidth();

            // ── Barra izquierda de acento en pie ─────────────────────────
            $this->SetFillColor($this->brand_r, $this->brand_g, $this->brand_b);
            $this->Rect(0, $this->getPageHeight() - 14, 6, 14, 'F');

            // ── Fondo gris muy suave ──────────────────────────────────────
            $this->SetFillColor(248, 248, 248);
            $this->Rect(6, $this->getPageHeight() - 14, $pageW - 6, 14, 'F');

            // ── Línea superior del pie ────────────────────────────────────
            $this->SetDrawColor($this->brand_r, $this->brand_g, $this->brand_b);
            $this->SetLineWidth(0.4);
            $this->Line(6, $this->getPageHeight() - 14, $pageW, $this->getPageHeight() - 14);

            $this->SetY($this->getPageHeight() - 11);
            $this->SetFont('Helvetica', 'B', 7.5);
            $this->SetTextColor(80, 80, 80);
            $this->SetX(12);
            $this->Cell(80, 4, 'Tictac Comunicación Digital SL', 0, 0, 'L');

            $this->SetFont('Helvetica', '', 7);
            $this->SetTextColor(130, 130, 130);
            $this->Cell(0, 4, 'C. Cruz Conde, 19, 6º 5 · 14001 Córdoba · 633 33 53 90 · hola@tictac-comunicacion.es', 0, 0, 'C');

            $this->SetFont('Helvetica', 'B', 7);
            $this->SetTextColor($this->brand_r, $this->brand_g, $this->brand_b);
            $this->SetX(0);
            $this->Cell($pageW - 10, 4, $this->PageNo() . ' / ' . $this->getNumPages(), 0, 0, 'R');
        }
    }

}